<?php
date_default_timezone_set('America/Los_Angeles');
 //thư mục cần duyệt
define('PATH', './'); // Khai báo đường đẫn đến thư mục
$files = array();
$dir = opendir(PATH);
while ($f = readdir($dir)){
if(preg_match("/(\.gif|\.jpg|\.png|\.jpeg)$/",$f))
array_push($files,$f);
}
closedir($dir);


?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">
  
    <title>Gallery Templates</title>
    <style>

    	/*Google fonts
==============================*/
@import url(https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700);
@import url(https://fonts.googleapis.com/css?family=Arimo:400,400italic,700,700italic);
@import url(https://fonts.googleapis.com/css?family=Oswald:400,300,700);

/*Body
==============================*/
body{
    overflow-x: hidden;
    width: 100%;
    font-family: arimo;
    color: #6c6c6c;
    font-size: 14px;
}
p
{
    color: #fff;
    font-family: 'oswald', sans-serif;
}
#service-provide{
    padding: 80px 0;
    color: #333;
}
#service-provide h2{
    color: #333;
}

.col-pic{
    position:absolute;
    top:0;
    width:100%;
    height:100%;
    text-align:center;
    padding-top: 6.5em;
    background: rgba(0, 0, 0, 0.43);


}
.col-pic p{
    color:#fff;
    font-size:1.1em;
    text-transform:uppercase;
    font-family: 'Oxygen-Bold';
}
.col-pic h5{
    color:#fff;
    font-size: 20px;
     font-family: 'roboto slab', sans-serif;
    letter-spacing: 0.25px;
}
.col-pic label{
    width:100px;
    height:2px;
    display:block;
    background:#fff;
    border-radius:10px;
    margin: 0.5em auto;
}

.col-3{
    position:relative;
    margin-bottom:1.5em;
    z-index: 0;
    -webkit-transform: scale(1);
    -moz-transform: scale(1);
    -ms-transform: scale(1);
    -o-transform: scale(1);
    transform: scale(1);
    -webkit-transition: all 2.2s ease-in-out;
    -moz-transition: all 2.2s ease-in-out;
    -ms-transition: all 2.2s ease-in-out;
    -o-transition: all 2.2s ease-in-out;
    transition: all 2.2s ease-in-out;

}
.col-3 a img
{
    -webkit-transition: all 2.4s ease-in-out;
    -moz-transition: all 2.4s ease-in-out;
    -ms-transition: all 2.4s ease-in-out;
    -o-transition: all 2.4s ease-in-out;
    transition: all 2.4s ease-in-out;
    height:320px;
    width:100%;
 
}

.col-3 a
{
    display: block;
    overflow: hidden;
    position: relative;
    -webkit-transform: translate3d(0, 0, 0);
    -moz-transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
    -o-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
}

.col-3 a:hover img
{
    -webkit-transform: scale(1.5);
    -moz-transform: scale(1.5);
    -ms-transform: scale(1.5);
    -o-transform: scale(1.5);
    transform: scale(1.5);
}
.col-3:hover .col-pic
{
    background:rgba(0, 0, 0, 0.59);
}

.padcol {
    padding-left:1px;
    padding-right:2px;
    margin-top: -17px;
}
.margright
{
    margin-right: -2px;
}

</style>
</head>
<body>
  <div class="container">
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="col-12">
 <div class="text-center">  <b>DANH SÁCH ẢNH</b> </div>
    </div>
    </div>
    </div>
    </div>
  <div class="container">
<div class="row">
    <div class="col-md-12 col-sm-12 ">
        <div class="col-12">
 <div class="text-center">
                            <p class="mb-3 text-xl">
<br>    </p>
        </div>
    </div>
<div class="row">
<?php $data = array();
if(!empty($files)){
foreach ($files as $k => $v){
echo '

    <div class="col-md-4 col-sm-4 padcol ">
        <div class="col-3">
            <a href="'.$v.'" target="_blank"><img src="'.$v.'" class="img-responsive" alt="" >
                <div class="col-pic"><h5>Bấm vào hình để xem</h5>
                </div></a>
        </div>
    </div>

            ';
}
}
?>
            
 

     
</div>
 </div> 
 </div> 