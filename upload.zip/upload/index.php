<?php
date_default_timezone_set('America/Los_Angeles');

?>
 

<html>  
 <head>  
  <meta name="viewport" content="initial-scale=1.0, user-scalable=no">  
  <meta charset="utf-8">  
  <title>TRANG WEB UP ẢNH CỰU HỌC SINH AN LƯƠNG</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
<style>  
form {
  margin-top: 50px;
}

input[type=file] {
	position: absolute;
	top: 0;
	right: 0;
	margin: 0;
	padding: 0;
	font-size: 20px;
	cursor: pointer;
	opacity: 0;
	filter: alpha(opacity=0);
}

</style>  
 </head>  
 <body>  
  <div class="container"> 
      <form method="post" id="fileupload" enctype="multipart/form-data"  accept-charset="utf-8">  
    <div class="col-md-4 col-md-offset-4">
	    <div class="col-md-12 col-sm-12 ">
        <div class="col-12">
 <div class="text-center">  <b>Website up ảnh của Cựu học Sinh An Lương</b> <br><a href="./uploads/" target="_blank">XEM ẢNH ĐÃ UP TẠI ĐÂY</a></div>
    </div>
    </div>
      <div class="input-group">
          <span class="input-group-btn">
            <div class="btn btn-default browse-button">
                <span class="browse-button-text">
                <i class="fa fa-folder-open"></i> Chọn ảnh</span>
                <input  type="file" name="fileupload" id="fileupload" accept=".jpg,.JPG,.PNG,.GIF,.JPEG,.png,.gif,.jpeg" />
            </div>
            <button type="button" class="btn btn-default clear-button" style="display:none;">
              <span class="fa fa-times"></span> Xóa
            </button>
          </span>
          <input type="text" class="form-control filename" disabled="disabled" placeholder="Please click on browse button and select a pdf file">
          <span class="input-group-btn">
            <button class="btn btn-primary upload-button" type="submit" name="upload" id="upload" >
                <i class="fa fa-upload"></i>
                Up ảnh
              </button>
          </span>
        </div>
		 <br />  
   <br />  
   <div id="preview"></div>  
   <br />  
   <br />  
    </div>
</form> 
  </div>  
 </body>  
</html>  
<script> 
$(".browse-button input:file").change(function (){
  $("input[name='fileupload']").each(function() {
    var fileName = $(this).val().split('/').pop().split('\\').pop();
    $(".filename").val(fileName);
    $(".browse-button-text").html('<i class="fa fa-refresh"></i> Đổi file');
    $(".clear-button").show();
  });
});

//actions happening when the button is clicked
$('.clear-button').click(function(){
    $('.filename').val("");
    $('.clear-button').hide();
    $('.browse-button input:file').val("");
    $(".browse-button-text").html('<i class="fa fa-folder-open"></i> Chọn ảnh'); 
});  
$(document).ready(function(){   
    $('#fileupload').on('submit', function(event){
     event.preventDefault();
     $.ajax({
      url:"upload.php",
      method:"POST",
      data:new FormData(this),
      contentType:false,
      cache:false,
      processData:false,
      success:function(data){
       $('#preview').html(data);
      }
     })
    });
});  
</script>
